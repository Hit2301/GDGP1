import React, { useEffect, useState } from 'react';
import Login from './components/Login';
import Signup from './components/Signup';
import Dashboard from './components/Dashboard';
import { auth } from './firebase';
import { onAuthStateChanged } from 'firebase/auth';

export default function App(){
  const [user, setUser] = useState(null);
  const [view, setView] = useState('login'); // login | signup | dashboard

  useEffect(()=> {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      if(u) setView('dashboard');
      else setView('login');
    });
    return () => unsub();
  },[]);

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-3xl w-full">
        {!user && view === 'login' && <Login onSwitch={()=>setView('signup')} />}
        {!user && view === 'signup' && <Signup onSwitch={()=>setView('login')} />}
        {user && <Dashboard user={user} />}
      </div>
    </div>
  );
}
