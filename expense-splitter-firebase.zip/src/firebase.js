// Firebase initialization (replace config if needed)
import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyAoddqc3ahy_Q-hUI9HjRlLEBmdSrmwdHs",
  authDomain: "gdg0111.firebaseapp.com",
  projectId: "gdg0111",
  storageBucket: "gdg0111.firebasestorage.app",
  messagingSenderId: "737666672090",
  appId: "1:737666672090:web:164d2009a53b41af648ce3",
  measurementId: "G-C8P93S26XE"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const provider = new GoogleAuthProvider();
export const db = getFirestore(app);
