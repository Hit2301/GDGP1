import React, { useEffect, useState } from 'react';
import { auth, db } from '../firebase';
import { signOut } from 'firebase/auth';
import {
  collection, addDoc, onSnapshot, query, where, orderBy, serverTimestamp
} from 'firebase/firestore';

export default function Dashboard({ user }){
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [participantsText, setParticipantsText] = useState(''); // comma separated
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(()=> {
    const q = query(collection(db, 'expenses'), where('ownerUid', '==', user.uid), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(q, (snap) => {
      const arr = [];
      snap.forEach(doc => arr.push({ id: doc.id, ...doc.data() }));
      setExpenses(arr);
    });
    return () => unsub();
  },[user.uid]);

  async function handleAdd(e){
    e?.preventDefault();
    const amt = parseFloat(amount);
    if(!title || !amount || isNaN(amt)) return alert('Please enter valid title and amount');
    setLoading(true);
    const participants = participantsText.split(',').map(s=>s.trim()).filter(Boolean);
    if(participants.length === 0) participants.push(user.email);
    try {
      await addDoc(collection(db,'expenses'), {
        ownerUid: user.uid,
        title,
        amount: amt,
        participants,
        createdAt: serverTimestamp()
      });
      setTitle(''); setAmount(''); setParticipantsText('');
    } catch(err){
      alert(err.message);
    } finally { setLoading(false); }
  }

  function computeShares(exp){
    const n = exp.participants.length;
    if(n === 0) return {};
    const per = exp.amount / n;
    const map = {};
    exp.participants.forEach(p => { map[p] = (map[p] || 0) + per; });
    return map;
  }

  function aggregateTotals(){
    const totals = {};
    expenses.forEach(exp => {
      const shares = computeShares(exp);
      Object.entries(shares).forEach(([person, val]) => {
        totals[person] = (totals[person] || 0) + val;
      });
    });
    return totals;
  }

  const totals = aggregateTotals();

  return (
    <div className="bg-white border rounded-lg shadow p-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold">Dashboard</h2>
        <div>
          <span className="mr-3 text-sm">Hi, {user.displayName || user.email}</span>
          <button className="text-sm text-red-600" onClick={()=>signOut(auth)}>Logout</button>
        </div>
      </div>

      <div className="mt-6 grid md:grid-cols-2 gap-6">
        <div>
          <h3 className="font-medium mb-2">Add Expense</h3>
          <form onSubmit={handleAdd} className="space-y-3">
            <input className="w-full p-2 border rounded" placeholder="Title (e.g., Dinner)" value={title} onChange={e=>setTitle(e.target.value)} />
            <input className="w-full p-2 border rounded" placeholder="Amount (e.g., 500)" value={amount} onChange={e=>setAmount(e.target.value)} />
            <input className="w-full p-2 border rounded" placeholder="Participants (comma separated emails). Leave empty for just you" value={participantsText} onChange={e=>setParticipantsText(e.target.value)} />
            <button className="py-2 px-4 rounded bg-blue-600 text-white" disabled={loading}>{loading ? 'Adding...' : 'Add Expense'}</button>
          </form>

          <div className="mt-6">
            <h4 className="font-medium">Totals (per person)</h4>
            <ul className="mt-2">
              {Object.entries(totals).length === 0 && <li className="text-sm text-gray-600">No expenses yet</li>}
              {Object.entries(totals).map(([person, val])=>(
                <li key={person} className="text-sm">{person}: ₹{val.toFixed(2)}</li>
              ))}
            </ul>
          </div>
        </div>

        <div>
          <h3 className="font-medium mb-2">Expenses</h3>
          <div className="space-y-3">
            {expenses.length === 0 && <div className="text-sm text-gray-600">No expenses yet</div>}
            {expenses.map(exp=>(
              <div key={exp.id} className="p-3 border rounded">
                <div className="flex justify-between">
                  <div>
                    <div className="font-medium">{exp.title}</div>
                    <div className="text-sm text-gray-600">By you • {exp.participants.join(', ')}</div>
                  </div>
                  <div className="text-lg font-semibold">₹{exp.amount.toFixed(2)}</div>
                </div>
                <div className="mt-2 text-sm">Split: {exp.participants.length} — each ₹{(exp.amount/exp.participants.length).toFixed(2)}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-6 text-sm text-gray-600">
        Tip: Use emails as participants so each person’s total is tracked. Later we can add groups, settle-ups, and export.
      </div>
    </div>
  );
}
