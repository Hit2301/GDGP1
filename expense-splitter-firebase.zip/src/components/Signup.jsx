import React, { useState } from 'react';
import { auth } from '../firebase';
import { createUserWithEmailAndPassword, updateProfile } from 'firebase/auth';

export default function Signup({ onSwitch }){
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [msg, setMsg] = useState(null);
  const [loading, setLoading] = useState(false);

  async function handleSignup(e){
    e?.preventDefault();
    setLoading(true); setMsg(null);
    try {
      const userCred = await createUserWithEmailAndPassword(auth, email, password);
      if(name) await updateProfile(userCred.user, { displayName: name });
      setMsg('Account created. You are now signed in.');
    } catch(err){
      setMsg(err.message);
    } finally { setLoading(false); }
  }

  return (
    <div className="bg-white border rounded-lg shadow p-6">
      <h2 className="text-2xl font-semibold mb-4">Create an account</h2>
      <form onSubmit={handleSignup} className="space-y-4">
        <input className="w-full p-3 border rounded" placeholder="Full name (optional)" value={name} onChange={e=>setName(e.target.value)} />
        <input className="w-full p-3 border rounded" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input className="w-full p-3 border rounded" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        <button className="w-full py-3 rounded bg-blue-600 text-white" disabled={loading}>{loading ? 'Creating...' : 'Sign up'}</button>
      </form>
      {msg && <p className="mt-3 text-sm">{msg}</p>}
      <p className="mt-4 text-sm">Already have an account? <button className="text-blue-600 underline" onClick={onSwitch}>Sign in</button></p>
    </div>
  );
}
