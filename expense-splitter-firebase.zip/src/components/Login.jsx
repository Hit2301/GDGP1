import React, { useState } from 'react';
import { auth, provider } from '../firebase';
import { signInWithEmailAndPassword, signInWithPopup } from 'firebase/auth';

export default function Login({ onSwitch }){
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState(null);
  const [loading, setLoading] = useState(false);

  async function handleEmailLogin(e){
    e?.preventDefault();
    setLoading(true); setMsg(null);
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (err) {
      setMsg(err.message);
    } finally { setLoading(false); }
  }

  async function handleGoogle(){
    try {
      await signInWithPopup(auth, provider);
    } catch(err){
      setMsg(err.message);
    }
  }

  return (
    <div className="bg-white border rounded-lg shadow p-6">
      <h2 className="text-2xl font-semibold mb-4">Sign in</h2>
      <form onSubmit={handleEmailLogin} className="space-y-4">
        <input className="w-full p-3 border rounded" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input className="w-full p-3 border rounded" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        <button className="w-full py-3 rounded bg-blue-600 text-white" disabled={loading}>{loading ? 'Signing in...' : 'Sign in'}</button>
      </form>
      <div className="my-3 text-center">or</div>
      <button onClick={handleGoogle} className="w-full py-3 rounded border">Continue with Google</button>
      {msg && <p className="mt-3 text-sm text-red-600">{msg}</p>}
      <p className="mt-4 text-sm">Don't have an account? <button className="text-blue-600 underline" onClick={onSwitch}>Create one</button></p>
    </div>
  );
}
