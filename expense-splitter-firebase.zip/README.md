# Expense Splitter - Firebase Starter (React)

Features:
- Firebase Authentication (Email/Password + Google Sign-In)
- Firestore to store expenses
- Add expense with participants (comma-separated emails)
- View expenses and per-person totals
- Light theme with Tailwind CDN

## Quick start

1. Extract the zip.
2. Install dependencies:
```bash
npm install
```
3. Start the dev server:
```bash
npm start
```
4. Open http://localhost:3000

## Notes
- Firebase config is already set in `src/firebase.js` with the values you provided.
- Firestore rules: For simple local testing, you can set Firestore rules to allow authenticated users to read/write their own docs. Example rule to allow authenticated read/write:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /expenses/{doc} {
      allow read, write: if request.auth != null && request.auth.uid == resource.data.ownerUid;
    }
  }
}
```
- For production, secure rules properly.
- Want features next: groups, settle-up calculation, receipts upload, or Pro features? Tell me which and I’ll add step-by-step.
