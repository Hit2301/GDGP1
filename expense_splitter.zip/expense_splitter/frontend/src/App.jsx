import React, { useState, useEffect } from "react";
import axios from "axios";
import { io } from "socket.io-client";

const API_BASE = "http://localhost:4000/api";
const socket = io("http://localhost:4000");

export default function App() {
  const [groups, setGroups] = useState([]);
  const [selected, setSelected] = useState(null);
  const [expenses, setExpenses] = useState([]);
  const [newExpense, setNewExpense] = useState({ amount: "", note: "" });

  useEffect(() => {
    axios.get(`${API_BASE}/groups`).then((res) => setGroups(res.data));
  }, []);

  const addExpense = async () => {
    const form = new FormData();
    form.append("payer_id", "test");
    form.append("amount", newExpense.amount);
    form.append("note", newExpense.note);
    form.append("splits", JSON.stringify([{ userId: "test", share: newExpense.amount }]));
    await axios.post(`${API_BASE}/groups/${selected.id}/expenses`, form);
    socket.emit("new_expense", { groupId: selected.id });
  };

  useEffect(() => {
    socket.on("expense-added", (data) => {
      if (selected && data.groupId === selected.id) {
        axios.get(`${API_BASE}/groups/${selected.id}`).then((res) => {
          setExpenses(res.data.expenses);
        });
      }
    });
  }, [selected]);

  return (
    <div className="app">
      <h2>💸 Expense Splitter</h2>
      {!selected ? (
        <>
          <h3>Groups</h3>
          {groups.map((g) => (
            <div key={g.id} onClick={() => setSelected(g)} style={{ cursor: "pointer", padding: 8 }}>
              {g.name}
            </div>
          ))}
        </>
      ) : (
        <>
          <button onClick={() => setSelected(null)}>⬅ Back</button>
          <h3>{selected.name}</h3>

          <div>
            <input
              type="number"
              placeholder="Amount"
              value={newExpense.amount}
              onChange={(e) => setNewExpense({ ...newExpense, amount: e.target.value })}
            />
            <input
              type="text"
              placeholder="Note"
              value={newExpense.note}
              onChange={(e) => setNewExpense({ ...newExpense, note: e.target.value })}
            />
            <button onClick={addExpense}>Add Expense</button>
          </div>

          <ul>
            {expenses.map((e) => (
              <li key={e.id}>{e.note} — ₹{e.amount}</li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}
