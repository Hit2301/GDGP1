# Expense Splitter Frontend (React + Vite)

## Setup
```bash
npm install
```

## Run the development server
```bash
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

Make sure the backend (FastAPI server) is running at **http://localhost:4000**.
