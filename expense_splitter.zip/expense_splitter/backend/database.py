from sqlalchemy import create_engine, Column, String, Float, ForeignKey, Boolean, DateTime, Text
from sqlalchemy.orm import sessionmaker, declarative_base, relationship
from datetime import datetime

DATABASE_URL = "sqlite:///./data.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)
Base = declarative_base()

class Group(Base):
    __tablename__ = "groups"
    id = Column(String, primary_key=True)
    name = Column(String)
    is_trip = Column(Boolean, default=False)
    trip_end = Column(String, nullable=True)
    members = relationship("GroupMember", back_populates="group")
    expenses = relationship("Expense", back_populates="group")

class User(Base):
    __tablename__ = "users"
    id = Column(String, primary_key=True)
    name = Column(String)
    avatar = Column(String, nullable=True)

class GroupMember(Base):
    __tablename__ = "group_members"
    id = Column(String, primary_key=True)
    group_id = Column(String, ForeignKey("groups.id"))
    user_id = Column(String, ForeignKey("users.id"))
    group = relationship("Group", back_populates="members")
    user = relationship("User")

class Expense(Base):
    __tablename__ = "expenses"
    id = Column(String, primary_key=True)
    group_id = Column(String, ForeignKey("groups.id"))
    payer_id = Column(String, ForeignKey("users.id"))
    amount = Column(Float)
    note = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    meta = Column(Text)
    group = relationship("Group", back_populates="expenses")
    splits = relationship("Split", back_populates="expense")

class Split(Base):
    __tablename__ = "splits"
    id = Column(String, primary_key=True)
    expense_id = Column(String, ForeignKey("expenses.id"))
    user_id = Column(String, ForeignKey("users.id"))
    share = Column(Float)
    expense = relationship("Expense", back_populates="splits")

def init_db():
    Base.metadata.create_all(bind=engine)
