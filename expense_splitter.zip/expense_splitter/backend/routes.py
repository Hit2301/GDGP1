from fastapi import APIRouter, UploadFile, File, Form, Depends
from sqlalchemy.orm import Session
from uuid import uuid4
import json, shutil
from database import SessionLocal, Group, User, GroupMember, Expense, Split

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/groups")
def create_group(name: str = Form(...), is_trip: bool = False, trip_end: str = None, db: Session = Depends(get_db)):
    group = Group(id=str(uuid4()), name=name, is_trip=is_trip, trip_end=trip_end)
    db.add(group)
    db.commit()
    return {"id": group.id, "name": group.name, "is_trip": group.is_trip, "trip_end": group.trip_end}

@router.get("/groups")
def list_groups(db: Session = Depends(get_db)):
    return db.query(Group).all()

@router.post("/users")
def create_user(name: str = Form(...), avatar: str = None, db: Session = Depends(get_db)):
    user = User(id=str(uuid4()), name=name, avatar=avatar)
    db.add(user)
    db.commit()
    return {"id": user.id, "name": user.name}

@router.post("/groups/{group_id}/members")
def add_member(group_id: str, user_id: str = Form(...), db: Session = Depends(get_db)):
    gm = GroupMember(id=str(uuid4()), group_id=group_id, user_id=user_id)
    db.add(gm)
    db.commit()
    return {"ok": True}

@router.post("/groups/{group_id}/expenses")
def add_expense(
    group_id: str,
    payer_id: str = Form(...),
    amount: float = Form(...),
    note: str = Form(""),
    splits: str = Form(...),
    receipt: UploadFile = File(None),
    db: Session = Depends(get_db),
):
    file_path = None
    if receipt:
        dest = f"uploads/{receipt.filename}"
        with open(dest, "wb") as buffer:
            shutil.copyfileobj(receipt.file, buffer)
        file_path = dest

    expense = Expense(
        id=str(uuid4()),
        group_id=group_id,
        payer_id=payer_id,
        amount=amount,
        note=note,
        meta=json.dumps({"receipt": file_path}),
    )
    db.add(expense)
    db.commit()

    parsed_splits = json.loads(splits)
    for s in parsed_splits:
        split = Split(id=str(uuid4()), expense_id=expense.id, user_id=s["userId"], share=s["share"])
        db.add(split)
    db.commit()
    return {"message": "Expense added successfully", "id": expense.id}

@router.get("/groups/{group_id}")
def get_group(group_id: str, db: Session = Depends(get_db)):
    group = db.query(Group).filter(Group.id == group_id).first()
    if not group:
        return {"error": "Group not found"}
    members = db.query(User).join(GroupMember).filter(GroupMember.group_id == group_id).all()
    expenses = db.query(Expense).filter(Expense.group_id == group_id).all()
    for e in expenses:
        e.splits = db.query(Split).filter(Split.expense_id == e.id).all()
    return {"group": group, "members": members, "expenses": expenses}
