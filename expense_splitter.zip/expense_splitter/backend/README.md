# Expense Splitter Backend (Python + FastAPI)

## Setup
```bash
pip install -r requirements.txt
```

## Run Server
```bash
python main.py
```

Server runs at `http://localhost:4000`

API routes start with `/api/`, e.g.:
- `POST /api/groups`
- `POST /api/users`
- `POST /api/groups/{groupId}/expenses`
