from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import socketio
import eventlet
from routes import router
from database import init_db

# Initialize
init_db()
sio = socketio.Server(cors_allowed_origins="*")
app = FastAPI()
app.include_router(router, prefix="/api")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@sio.event
def connect(sid, environ):
    print("Client connected:", sid)

@sio.event
def join_group(sid, data):
    sio.enter_room(sid, data)
    print(f"{sid} joined {data}")

@sio.event
def new_expense(sid, data):
    sio.emit("expense-added", data, room=data["groupId"])

@sio.event
def disconnect(sid):
    print("Client disconnected:", sid)

# Mount Socket.IO
from socketio import ASGIApp
app = ASGIApp(sio, other_asgi_app=app)

if __name__ == "__main__":
    eventlet.wsgi.server(eventlet.listen(("0.0.0.0", 4000)), app)
